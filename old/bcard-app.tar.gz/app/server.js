const express = require('express');
const fs = require('fs');
const path = require('path');
const multer = require('multer');

const app = express();
// Теперь порт по умолчанию 3005, чтобы не мешать Nginx
const PORT = process.env.PORT || 3005; 
const dataFile = path.join(__dirname, 'data.json');
const uploadsDir = path.join(__dirname, 'uploads');

if (!fs.existsSync(uploadsDir)) fs.mkdirSync(uploadsDir);

const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, 'uploads/'),
  filename: (req, file, cb) => cb(null, `photo_${Date.now()}${path.extname(file.originalname)}`)
});
const upload = multer({ storage, limits: { fileSize: 5 * 1024 * 1024 } });

app.use(express.json());
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

const defaultData = [
  { id: 'emp_001', name: "Александр Смирнов", role: "Генеральный директор", phone: "+7 (999) 123-45-67", email: "a.smirnov@su10.ru", tg: "asmirnov_su10", photo: "https://images.unsplash.com/photo-1560250097-0b93528c311a?auto=format&fit=crop&w=250&q=80" },
  { id: 'emp_002', name: "Елена Волкова", role: "Директор по строительству", phone: "+7 (999) 765-43-21", email: "e.volkova@su10.ru", tg: "volkova_build", photo: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=250&q=80" }
];

if (!fs.existsSync(dataFile)) fs.writeFileSync(dataFile, JSON.stringify(defaultData, null, 2));

app.get('/api/employees', (req, res) => res.json(JSON.parse(fs.readFileSync(dataFile, 'utf8'))));
app.post('/api/employees', (req, res) => {
  const data = JSON.parse(fs.readFileSync(dataFile, 'utf8'));
  const newEmp = { id: 'emp_' + Date.now(), ...req.body };
  data.push(newEmp);
  fs.writeFileSync(dataFile, JSON.stringify(data, null, 2));
  res.json(newEmp);
});
app.put('/api/employees/:id', (req, res) => {
  const data = JSON.parse(fs.readFileSync(dataFile, 'utf8'));
  const index = data.findIndex(e => e.id === req.params.id);
  if (index > -1) {
    data[index] = { ...data[index], ...req.body };
    fs.writeFileSync(dataFile, JSON.stringify(data, null, 2));
    res.json(data[index]);
  } else res.status(404).json({ error: 'Не найден' });
});
app.post('/api/upload', upload.single('photo'), (req, res) => {
  if (!req.file) return res.status(400).json({ error: 'Файл не загружен' });
  res.json({ url: `/uploads/${req.file.filename}` });
});

app.use(express.static(path.join(__dirname, 'frontend/dist')));
app.get('*', (req, res) => res.sendFile(path.join(__dirname, 'frontend/dist/index.html')));

app.listen(PORT, '0.0.0.0', () => console.log(`Server running on port ${PORT}`));
